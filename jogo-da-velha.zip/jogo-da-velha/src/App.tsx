
import Celula from './celula';
import { useState } from 'react';

function App() {
  const [tabuleiro, setTabuleiro] = useState(['','','','','','','','','']);
  const [jogador, setJogador] = useState('O');
  const proximoTurno = () => {
    if(jogador === 'O'){
      setJogador('X');
    }else{
      setJogador('O');
    }
  };

  const limparTabuleiro = () => {
    setTabuleiro([]);
  }

  return (
    <div className="jogo">
        <div className="tabuleiro">
          {tabuleiro.map((celula,i) => (
            <Celula 
              key={i} 
              valor={celula}
              jogador={jogador}
              onMarcacao={proximoTurno}
            />
          ))}
        </div>
        <button className="btnLimpar" onClick={limparTabuleiro}>
            Limpar
        </button>
    </div>
  )
}

export default App;
