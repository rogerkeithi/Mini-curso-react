import { useState } from "react";

type Props = {
    valor:string;
    jogador:string;
    onMarcacao:() => void;
};

export default function Celula(props: Props){
    const [valor, setValor] = useState(props.valor);

    const marcarCelula = () => {
        if(valor === ''){
            setValor(props.jogador);
            props.onMarcacao();
        }
    }

    return (
        <div className="celula" onClick={marcarCelula}>
            <span>{valor}</span>
        </div>
    )
}